module.exports = function(Motorcycle) {

};
